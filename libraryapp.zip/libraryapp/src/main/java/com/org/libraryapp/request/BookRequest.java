/**
 * 
 */
package com.org.libraryapp.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author attip
 *
 */

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BookRequest {

	private String id;

	private String bookName;

	private String iSBNumber;

	private String title;

	private String author;

}
