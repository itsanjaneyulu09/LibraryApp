/**
 * 
 */
package com.org.libraryapp.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.org.libraryapp.model.Book;
import com.org.libraryapp.repository.BookRepository;
import com.org.libraryapp.request.BookRequest;
import com.org.libraryapp.request.BookSearch;
import com.org.libraryapp.request.PageableRequest;
import com.org.libraryapp.request.SearchCriteria;
import com.org.libraryapp.request.SearchOperation;
import com.org.libraryapp.response.CommonResponse;
import com.org.libraryapp.response.MainPageResponse;
import com.org.libraryapp.util.BasicUtill;
import com.org.libraryapp.util.GenericSpesification;

/**
 * @author attip
 *
 */
@Service
@Transactional
public class BookService {

	private static final Logger logger = LoggerFactory.getLogger(BookService.class);

	private static final String SUCCESS = "Success";

	@Autowired
	private BookRepository bookRepository;

	@Autowired
	private BasicUtill basicUtill;

	public CommonResponse addBooks(List<BookRequest> bookRequests) {
		// TODO Auto-generated method stub
		var addBooks = basicUtill.convertListOfObjectsByMap(bookRequests, Book.class);
		var booksResp = bookRepository.saveAll(addBooks);
		var commonResponse = new CommonResponse();
		commonResponse.setMessage(SUCCESS);
		commonResponse.setData(booksResp);
		return commonResponse;
	}

	public MainPageResponse searchBooks(BookSearch bookSearch, PageableRequest pageRequest) {
		// TODO Auto-generated method stub
		int pageNumber = pageRequest.getPageNo() - 1;
		Pageable pageable = PageRequest.of(pageNumber <= 0 ? 0 : pageNumber,
				pageRequest.getPageSize() <= 0 ? 10 : pageRequest.getPageSize());

		var genericSpesification = new GenericSpesification<Book>();
		genericSpesification.add(new SearchCriteria("id", bookSearch.getId(), SearchOperation.EQUAL));
		genericSpesification.add(new SearchCriteria("bookName", bookSearch.getBookName(), SearchOperation.EQUAL));
		var mainResp = bookRepository.findAll(genericSpesification, pageable);

		long totalElements = mainResp.getTotalElements();
		int totalPages = mainResp.getTotalPages();
		var content = mainResp.getContent();

		var mainPageResp = new MainPageResponse();
		mainPageResp.setPageNo(mainResp.getPageable().getPageNumber() + 1);
		mainPageResp.setPageSize(mainResp.getPageable().getPageSize());
		mainPageResp.setTotalElements(totalElements);
		mainPageResp.setTotalPages(totalPages);
		mainPageResp.setContent(content);
		logger.info("main resp " + basicUtill.convertJSONtoString(mainPageResp));
		return mainPageResp;
	}

}
