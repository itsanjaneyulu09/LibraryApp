/**
 * 
 */
package com.org.libraryapp.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author attip
 *
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class BorrowerSearch {

	private String id;

	private String borrowerName;

	private String email;

}
