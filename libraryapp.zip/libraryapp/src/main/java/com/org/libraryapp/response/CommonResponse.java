/**
 * 
 */
package com.org.libraryapp.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author attip
 *
 */


@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CommonResponse {

	private String message;
	
	private Object data;
	
}
