/**
 * 
 */
package com.org.libraryapp.util;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author attip
 *
 */
@Component
public class BasicUtill {

	private static final Logger logger = LoggerFactory.getLogger(BasicUtill.class);

	@Autowired
	private ModelMapper modelMapper;

	// convert one obj to another obj
	public <R> R convertObjectByMap(Object source, Class<R> resultClass) {
		return modelMapper.map(source, resultClass);
	}

	// convert list of objs to another list of objs
	public <S, T> List<T> convertListOfObjectsByMap(List<S> source, Class<T> targetClass) {
		return source.stream().map(element -> modelMapper.map(element, targetClass)).collect(Collectors.toList());
	}

	// convert Object to String
	public String convertJSONtoString(Object obj) {
		String jsonStr = "";
		ObjectMapper Obj = new ObjectMapper();

		try {
			// get object as a json string
			jsonStr = Obj.writeValueAsString(obj);

		} catch (IOException e) {
			e.printStackTrace();
		}
		return jsonStr;
	}

	// convert String to Date
	public LocalDate convertStringToDate(String date) {
		DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("dd-MM-yyy");
		LocalDate dateResp = null;
		dateResp = LocalDate.parse(date, dateFormat);
		return dateResp;
	}

	public boolean isNullOrEmpty(Object obj) {

		logger.info("obj> " + obj);
		if (obj == null || obj.equals("")) {
			return true;
		}
		return false;
	}
}
