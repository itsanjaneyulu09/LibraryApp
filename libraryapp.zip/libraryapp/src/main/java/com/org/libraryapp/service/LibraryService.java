/**
 * 
 */
package com.org.libraryapp.service;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.org.libraryapp.model.Library;
import com.org.libraryapp.repository.BookRepository;
import com.org.libraryapp.repository.BorrowerRepository;
import com.org.libraryapp.repository.LibraryRepository;
import com.org.libraryapp.request.LibraryRequest;
import com.org.libraryapp.response.CommonResponse;
import com.org.libraryapp.util.BasicUtill;

/**
 * @author attip
 *
 */
@Service
@Transactional
public class LibraryService {

	private static final Logger logger = LoggerFactory.getLogger(LibraryService.class);

	private static final String SUCCESS = "Success";

	@Autowired
	private BasicUtill basicUtill;

	@Autowired
	private BookRepository bookRepository;

	@Autowired
	private BorrowerRepository borrowerRepository;

	@Autowired
	private LibraryRepository libraryRepository;

	public CommonResponse barrowBooks(List<LibraryRequest> barrowBooksRequest) {
		// TODO Auto-generated method stub
		var commonResponse = new CommonResponse();
		var finalResp = new LinkedHashMap<String, Object>();

		var errorBarrowBooks = new ArrayList<LibraryRequest>();
		var successBarrowBooks = new ArrayList<Library>();

		for (LibraryRequest barrowBook : barrowBooksRequest) {
			var borrowerId = barrowBook.getBorrowerId();
			var bookId = barrowBook.getBookId();
			if (basicUtill.isNullOrEmpty(borrowerId) && !borrowerRepository.existsById(borrowerId)) {
				errorBarrowBooks.add(barrowBook);
//				return new CommonResponse("Borrower Not Exist", borrowerId);
			} else if (basicUtill.isNullOrEmpty(bookId) && !bookRepository.existsById(bookId)) {
				errorBarrowBooks.add(barrowBook);
//				return new CommonResponse("book Not Exist", bookId);
			} else if (libraryRepository.existsByBookIdAndBorrowerId(bookId, borrowerId)) {
				errorBarrowBooks.add(barrowBook);
			} else {
				var barrowBooks = basicUtill.convertObjectByMap(successBarrowBooks, Library.class);
				Library barrowBookResp = libraryRepository.save(barrowBooks);
				successBarrowBooks.add(barrowBookResp);
			}
		}
		var errorBarrowBooksResp = basicUtill.convertListOfObjectsByMap(errorBarrowBooks, Library.class);
		finalResp.put("successList", successBarrowBooks);
		finalResp.put("errorList", errorBarrowBooksResp);

		commonResponse.setMessage(SUCCESS);
		commonResponse.setData(finalResp);
		return commonResponse;
	}

	public CommonResponse removeBorrowBooks(LibraryRequest borrowBooksRequest) {
		// TODO Auto-generated method stub
		var bookId = borrowBooksRequest.getBookId();
		var borrowerId = borrowBooksRequest.getBorrowerId();
		if (!basicUtill.isNullOrEmpty(borrowerId) && !basicUtill.isNullOrEmpty(bookId)
				&& libraryRepository.existsByBookIdAndBorrowerId(bookId, borrowerId)) {
			libraryRepository.deleteByBookIdAndBorrowerId(bookId, borrowerId);
			return new CommonResponse(SUCCESS, null);
		} else {
			return new CommonResponse("Does not exist", null);
		}
	}

}
