/**
 * 
 */
package com.org.libraryapp.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.org.libraryapp.request.LibraryRequest;
import com.org.libraryapp.service.LibraryService;
import com.org.libraryapp.util.BasicUtill;

/**
 * @author attip
 *
 */
@RestController
@CrossOrigin("*")
@RequestMapping("/api")
public class LibraryController {

	private Logger logger = LoggerFactory.getLogger(LibraryController.class);

	@Autowired
	private LibraryService libraryService;

	@Autowired
	private BasicUtill basicUtill;

	@PostMapping("/addBorrowBooks")
	public ResponseEntity<?> addBorrowBooks(@RequestBody List<LibraryRequest> borrowBooksRequest) {
		return ResponseEntity.ok(libraryService.barrowBooks(borrowBooksRequest));
	}

	@DeleteMapping("/removeBorrowBooks")
	public ResponseEntity<?> removeBorrowBooks(@RequestBody LibraryRequest borrowBooksRequest) {
		return ResponseEntity.ok(libraryService.removeBorrowBooks(borrowBooksRequest));
	}

//	@PostMapping("/booksBySearch")
//	public ResponseEntity<?> searchBooks(@RequestBody BookSearch bookSearch, PageableRequest pageRequest) {
//		logger.info("start booksBySearch function " + " Employees: " + basicUtill.convertJSONtoString(bookSearch)
//				+ "Pageable: " + basicUtill.convertJSONtoString(pageRequest));
//
//		MainPageResponse searchBooks = bookService.searchBooks(bookSearch, pageRequest);
//		return ResponseEntity.ok(searchBooks);
//	}
}
