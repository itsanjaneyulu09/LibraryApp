/**
 * 
 */
package com.org.libraryapp.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author attip
 *
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PageableRequest {

	private int pageNo;

	private int pageSize;

}
