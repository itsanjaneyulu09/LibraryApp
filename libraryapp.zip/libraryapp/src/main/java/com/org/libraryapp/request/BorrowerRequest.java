/**
 * 
 */
package com.org.libraryapp.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author attip
 *
 */

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BorrowerRequest {

	private String id;

	private String borrowerName;

	private String email;

	private String bookId;

}
