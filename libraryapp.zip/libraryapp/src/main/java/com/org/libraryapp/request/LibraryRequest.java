/**
 * 
 */
package com.org.libraryapp.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author attip
 *
 */

@Data
@NoArgsConstructor
@AllArgsConstructor
public class LibraryRequest {

	private String id;

	private String bookId;

	private String bookName;

	private String borrowerId;

	private String borrowerName;

}
