/**
 * 
 */
package com.org.libraryapp.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author attip
 *
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class BookSearch {

	private String id;

	private String bookName;

	private String iSBNumber;

	private String title;

	private String author;

}
