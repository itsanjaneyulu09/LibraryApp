/**
 * 
 */
package com.org.libraryapp.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.org.libraryapp.request.BookRequest;
import com.org.libraryapp.request.BookSearch;
import com.org.libraryapp.request.PageableRequest;
import com.org.libraryapp.response.MainPageResponse;
import com.org.libraryapp.service.BookService;
import com.org.libraryapp.util.BasicUtill;

/**
 * @author attip
 *
 */
@RestController
@CrossOrigin("*")
@RequestMapping("/api")
public class BookController {

	private Logger logger = LoggerFactory.getLogger(BookController.class);

	@Autowired
	private BookService bookService;

	@Autowired
	private BasicUtill basicUtill;

	@PostMapping("/addBooks")
	public ResponseEntity<?> addBooks(@RequestBody List<BookRequest> bookRequests) {
		return ResponseEntity.ok(bookService.addBooks(bookRequests));
	}

	@PostMapping("/booksBySearch")
	public ResponseEntity<?> searchBooks(@RequestBody BookSearch bookSearch, PageableRequest pageRequest) {
		logger.info("start booksBySearch function " + " Employees: " + basicUtill.convertJSONtoString(bookSearch)
				+ "Pageable: " + basicUtill.convertJSONtoString(pageRequest));

		MainPageResponse searchBooks = bookService.searchBooks(bookSearch, pageRequest);
		return ResponseEntity.ok(searchBooks);
	}
}
