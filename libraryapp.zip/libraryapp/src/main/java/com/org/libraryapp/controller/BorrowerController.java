/**
 * 
 */
package com.org.libraryapp.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.org.libraryapp.request.BorrowerRequest;
import com.org.libraryapp.request.BorrowerSearch;
import com.org.libraryapp.request.PageableRequest;
import com.org.libraryapp.response.MainPageResponse;
import com.org.libraryapp.service.BorrowerService;
import com.org.libraryapp.util.BasicUtill;

/**
 * @author attip
 *
 */

@RestController
@CrossOrigin("*")
@RequestMapping("/api")
public class BorrowerController {

	private Logger logger = LoggerFactory.getLogger(BorrowerController.class);

	@Autowired
	private BorrowerService borrowerService;

	@Autowired
	private BasicUtill basicUtill;

	@PostMapping("/addBorrowers")
	public ResponseEntity<?> addBorrowers(@RequestBody List<BorrowerRequest> BorrowerRequests) {
		return ResponseEntity.ok(borrowerService.addBorrowers(BorrowerRequests));
	}

	@PostMapping("/borrowersBySearch")
	public ResponseEntity<?> searchBorrowers(@RequestBody BorrowerSearch borrowerSearch, PageableRequest pageRequest) {
		logger.info(
				"start BorrowersBySearch function " + " Employees: " + basicUtill.convertJSONtoString(borrowerSearch)
						+ "Pageable: " + basicUtill.convertJSONtoString(pageRequest));

		MainPageResponse searchBorrowers = borrowerService.searchBorrowers(borrowerSearch, pageRequest);
		return ResponseEntity.ok(searchBorrowers);
	}

}
