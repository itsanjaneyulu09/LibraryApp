/**
 * 
 */
package com.org.libraryapp.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.org.libraryapp.model.Borrower;
import com.org.libraryapp.repository.BookRepository;
import com.org.libraryapp.repository.BorrowerRepository;
import com.org.libraryapp.request.BorrowerRequest;
import com.org.libraryapp.request.BorrowerSearch;
import com.org.libraryapp.request.PageableRequest;
import com.org.libraryapp.request.SearchCriteria;
import com.org.libraryapp.request.SearchOperation;
import com.org.libraryapp.response.CommonResponse;
import com.org.libraryapp.response.MainPageResponse;
import com.org.libraryapp.util.BasicUtill;
import com.org.libraryapp.util.GenericSpesification;

/**
 * @author attip
 *
 */
@Service
@Transactional
public class BorrowerService {

	private static final Logger logger = LoggerFactory.getLogger(BorrowerService.class);

	private static final String SUCCESS = "Success";

	@Autowired
	private BasicUtill basicUtill;

	@Autowired
	private BookRepository bookRepository;

	@Autowired
	private BorrowerRepository borrowerRepository;

	public CommonResponse addBorrowers(List<BorrowerRequest> borrowerRequests) {
		// TODO Auto-generated method stub
		var commonResponse = new CommonResponse();
		var addBorrowers = basicUtill.convertListOfObjectsByMap(borrowerRequests, Borrower.class);
		var booksResp = borrowerRepository.saveAll(addBorrowers);
		commonResponse.setMessage(SUCCESS);
		commonResponse.setData(booksResp);
		return commonResponse;
	}

	public MainPageResponse searchBorrowers(BorrowerSearch borrowerSearch, PageableRequest pageRequest) {
		// TODO Auto-generated method stub
		int pageNumber = pageRequest.getPageNo() - 1;
		Pageable pageable = PageRequest.of(pageNumber <= 0 ? 0 : pageNumber,
				pageRequest.getPageSize() <= 0 ? 10 : pageRequest.getPageSize());

		var genericSpesification = new GenericSpesification<Borrower>();
		genericSpesification.add(new SearchCriteria("id", borrowerSearch.getId(), SearchOperation.EQUAL));
		genericSpesification
				.add(new SearchCriteria("borrowerName", borrowerSearch.getBorrowerName(), SearchOperation.EQUAL));
		genericSpesification.add(new SearchCriteria("email", borrowerSearch.getEmail(), SearchOperation.EQUAL));

		var mainResp = borrowerRepository.findAll(genericSpesification, pageable);

		long totalElements = mainResp.getTotalElements();
		int totalPages = mainResp.getTotalPages();
		var content = mainResp.getContent();

		var mainPageResp = new MainPageResponse();
		mainPageResp.setPageNo(mainResp.getPageable().getPageNumber() + 1);
		mainPageResp.setPageSize(mainResp.getPageable().getPageSize());
		mainPageResp.setTotalElements(totalElements);
		mainPageResp.setTotalPages(totalPages);
		mainPageResp.setContent(content);
		logger.info("main resp " + basicUtill.convertJSONtoString(mainPageResp));
		return mainPageResp;

	}

}
