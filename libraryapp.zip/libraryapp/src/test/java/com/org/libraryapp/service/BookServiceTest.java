/**
 * 
 */
package com.org.libraryapp.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import com.org.libraryapp.model.Book;
import com.org.libraryapp.repository.BookRepository;
import com.org.libraryapp.request.BookRequest;
import com.org.libraryapp.util.BasicUtill;

/**
 * @author attip
 *
 */

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
public class BookServiceTest {

	@InjectMocks
	private BookService bookService;

	@Mock
	private BookRepository bookRepository;

	@Mock
	private BasicUtill basicUtill;

	List<BookRequest> booksRequest = new ArrayList<BookRequest>();
	List<Book> booksResponse = new ArrayList<Book>();

	@BeforeEach
	public void init() {

		var bookRequestOne = new BookRequest();

		bookRequestOne.setAuthor("Java");
		bookRequestOne.setBookName("Java Note");
		bookRequestOne.setISBNumber("9934567866999");
		bookRequestOne.setTitle("Coding Language");
		bookRequestOne.setId("987652345699");

		var bookRequestTwo = new BookRequest();
		bookRequestTwo.setAuthor("SriKrishna");
		bookRequestTwo.setBookName("BhagavathGitha");
		bookRequestTwo.setISBNumber("345678999");
		bookRequestTwo.setTitle("Belive In You");
		bookRequestTwo.setId("9876545678999");

		booksRequest.add(bookRequestOne);
		booksRequest.add(bookRequestTwo);

		var bookResponseOne = new Book();

		bookResponseOne.setAuthor("Java");
		bookResponseOne.setBookName("Java Note");
		bookResponseOne.setISBNumber("9934567866999");
		bookResponseOne.setTitle("Coding Language");
		bookResponseOne.setId("987652345699");

		var bookResponseTwo = new Book();
		bookResponseTwo.setAuthor("SriKrishna");
		bookResponseTwo.setBookName("BhagavathGitha");
		bookResponseTwo.setISBNumber("345678999");
		bookResponseTwo.setTitle("Belive In You");
		bookResponseTwo.setId("9876545678999");

		booksResponse.add(bookResponseOne);
		booksResponse.add(bookResponseTwo);

	}

	@Test
	void addBooksTest() {

		when(basicUtill.convertListOfObjectsByMap(booksRequest, Book.class)).thenReturn(booksResponse);
		when(bookRepository.saveAll(booksResponse)).thenReturn(booksResponse);
		var result = bookService.addBooks(booksRequest);
		assertNotNull(booksRequest);
		assertNotNull(result);
		assertEquals(booksResponse, result.getData());

	}

}
